﻿namespace SMS_Bomber_V2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Exit_BTN = new RelyUI.Controls.RelyButton();
            this.About_BTN = new RelyUI.Controls.RelyButton();
            this.Leech_BTN = new RelyUI.Controls.RelyButton();
            this.Home_BTN = new RelyUI.Controls.RelyButton();
            this.xuiClock1 = new XanderUI.XUIClock();
            this.Leecher_GP = new RelyUI.Controls.RelyGroupBox();
            this.relyLabel11 = new RelyUI.Controls.RelyLabel();
            this.relyLabel1 = new RelyUI.Controls.RelyLabel();
            this.LIC_Check = new RelyUI.Controls.RelyLabel();
            this.relyLabel12 = new RelyUI.Controls.RelyLabel();
            this.LIC_Type = new RelyUI.Controls.RelyLabel();
            this.relyLabel9 = new RelyUI.Controls.RelyLabel();
            this.relyLabel13 = new RelyUI.Controls.RelyLabel();
            this.relyLabel16 = new RelyUI.Controls.RelyLabel();
            this.Net_Check = new RelyUI.Controls.RelyLabel();
            this.relyLabel15 = new RelyUI.Controls.RelyLabel();
            this.Site_Check = new RelyUI.Controls.RelyLabel();
            this.relyLabel14 = new RelyUI.Controls.RelyLabel();
            this.Acc_Check = new RelyUI.Controls.RelyLabel();
            this.relyLabel3 = new RelyUI.Controls.RelyLabel();
            this.relyLabel19 = new RelyUI.Controls.RelyLabel();
            this.relyLabel20 = new RelyUI.Controls.RelyLabel();
            this.relyLabel21 = new RelyUI.Controls.RelyLabel();
            this.relyLabel10 = new RelyUI.Controls.RelyLabel();
            this.relyLabel22 = new RelyUI.Controls.RelyLabel();
            this.relyLabel23 = new RelyUI.Controls.RelyLabel();
            this.relyLabel4 = new RelyUI.Controls.RelyLabel();
            this.relyLabel18 = new RelyUI.Controls.RelyLabel();
            this.Mobile_TXT = new RelyUI.Controls.RelyTextBox();
            this.Send_URL_BTN = new RelyUI.Controls.RelyButton();
            this.relyLabel17 = new RelyUI.Controls.RelyLabel();
            this.relyLabel2 = new RelyUI.Controls.RelyLabel();
            this.Donate_BTC_BTN = new RelyUI.Controls.RelyButton();
            this.Donate_IRR_BTN = new RelyUI.Controls.RelyButton();
            this.GitHub_BTN = new RelyUI.Controls.RelyButton();
            this.GP_BOX = new RelyUI.Controls.RelyGroupBox();
            this.Error_SEND_SMS_LBL = new RelyUI.Controls.RelyLabel();
            this.SEND_SMS_LBL = new RelyUI.Controls.RelyLabel();
            this.Mobile_LBL = new RelyUI.Controls.RelyLabel();
            this.relyLabel8 = new RelyUI.Controls.RelyLabel();
            this.relyLabel7 = new RelyUI.Controls.RelyLabel();
            this.relyLabel6 = new RelyUI.Controls.RelyLabel();
            this.TimeSMS = new System.Windows.Forms.Timer(this.components);
            this.STOP_URL_BTN = new RelyUI.Controls.RelyButton();
            this.Leecher_GP.SuspendLayout();
            this.GP_BOX.SuspendLayout();
            this.SuspendLayout();
            // 
            // Exit_BTN
            // 
            this.Exit_BTN.BackColor = System.Drawing.Color.Transparent;
            this.Exit_BTN.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.Exit_BTN.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Exit_BTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exit_BTN.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Exit_BTN.Location = new System.Drawing.Point(13, 249);
            this.Exit_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Exit_BTN.Name = "Exit_BTN";
            this.Exit_BTN.Rounded = true;
            this.Exit_BTN.RoundRadius = 3;
            this.Exit_BTN.Size = new System.Drawing.Size(201, 54);
            this.Exit_BTN.TabIndex = 12;
            this.Exit_BTN.Text = "Exit";
            this.Exit_BTN.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Exit_BTN.Click += new System.EventHandler(this.Exit_BTN_Click);
            // 
            // About_BTN
            // 
            this.About_BTN.BackColor = System.Drawing.Color.Transparent;
            this.About_BTN.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.About_BTN.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.About_BTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.About_BTN.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.About_BTN.Location = new System.Drawing.Point(13, 187);
            this.About_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.About_BTN.Name = "About_BTN";
            this.About_BTN.Rounded = true;
            this.About_BTN.RoundRadius = 3;
            this.About_BTN.Size = new System.Drawing.Size(201, 54);
            this.About_BTN.TabIndex = 11;
            this.About_BTN.Text = "About";
            this.About_BTN.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.About_BTN.Click += new System.EventHandler(this.About_BTN_Click);
            // 
            // Leech_BTN
            // 
            this.Leech_BTN.BackColor = System.Drawing.Color.Transparent;
            this.Leech_BTN.BaseColor = System.Drawing.Color.Teal;
            this.Leech_BTN.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Leech_BTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Leech_BTN.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Leech_BTN.Location = new System.Drawing.Point(13, 126);
            this.Leech_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Leech_BTN.Name = "Leech_BTN";
            this.Leech_BTN.Rounded = true;
            this.Leech_BTN.RoundRadius = 3;
            this.Leech_BTN.Size = new System.Drawing.Size(201, 54);
            this.Leech_BTN.TabIndex = 10;
            this.Leech_BTN.Text = "Sms Bomber";
            this.Leech_BTN.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Leech_BTN.Click += new System.EventHandler(this.Leech_BTN_Click);
            // 
            // Home_BTN
            // 
            this.Home_BTN.BackColor = System.Drawing.Color.Transparent;
            this.Home_BTN.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.Home_BTN.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Home_BTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home_BTN.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Home_BTN.Location = new System.Drawing.Point(13, 64);
            this.Home_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Home_BTN.Name = "Home_BTN";
            this.Home_BTN.Rounded = true;
            this.Home_BTN.RoundRadius = 3;
            this.Home_BTN.Size = new System.Drawing.Size(201, 54);
            this.Home_BTN.TabIndex = 9;
            this.Home_BTN.Text = "Home";
            this.Home_BTN.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Home_BTN.Click += new System.EventHandler(this.Home_BTN_Click);
            // 
            // xuiClock1
            // 
            this.xuiClock1.CircleThickness = 6;
            this.xuiClock1.DisplayFormat = XanderUI.XUIClock.HourFormat.TwentyFourHour;
            this.xuiClock1.FilledHourColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(190)))), ((int)(((byte)(155)))));
            this.xuiClock1.FilledMinuteColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            this.xuiClock1.FilledSecondColor = System.Drawing.Color.DarkOrchid;
            this.xuiClock1.Font = new System.Drawing.Font("Impact", 15F);
            this.xuiClock1.HexagonColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            this.xuiClock1.Location = new System.Drawing.Point(31, 301);
            this.xuiClock1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.xuiClock1.Name = "xuiClock1";
            this.xuiClock1.ShowAmPm = false;
            this.xuiClock1.ShowHexagon = false;
            this.xuiClock1.ShowMinutesCircle = true;
            this.xuiClock1.ShowSecondsCircle = true;
            this.xuiClock1.Size = new System.Drawing.Size(157, 150);
            this.xuiClock1.TabIndex = 13;
            this.xuiClock1.Text = "xuiClock1";
            this.xuiClock1.UnfilledHourColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(70)))), ((int)(((byte)(85)))));
            this.xuiClock1.UnfilledMinuteColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            this.xuiClock1.UnfilledSecondColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(70)))));
            // 
            // Leecher_GP
            // 
            this.Leecher_GP.BackColor = System.Drawing.Color.Transparent;
            this.Leecher_GP.BaseColor = System.Drawing.Color.Black;
            this.Leecher_GP.BorderColor = System.Drawing.Color.Gray;
            this.Leecher_GP.Controls.Add(this.relyLabel11);
            this.Leecher_GP.Controls.Add(this.GitHub_BTN);
            this.Leecher_GP.Controls.Add(this.STOP_URL_BTN);
            this.Leecher_GP.Controls.Add(this.Donate_IRR_BTN);
            this.Leecher_GP.Controls.Add(this.relyLabel1);
            this.Leecher_GP.Controls.Add(this.Donate_BTC_BTN);
            this.Leecher_GP.Controls.Add(this.LIC_Check);
            this.Leecher_GP.Controls.Add(this.relyLabel19);
            this.Leecher_GP.Controls.Add(this.relyLabel3);
            this.Leecher_GP.Controls.Add(this.relyLabel12);
            this.Leecher_GP.Controls.Add(this.GP_BOX);
            this.Leecher_GP.Controls.Add(this.LIC_Type);
            this.Leecher_GP.Controls.Add(this.relyLabel20);
            this.Leecher_GP.Controls.Add(this.relyLabel9);
            this.Leecher_GP.Controls.Add(this.relyLabel21);
            this.Leecher_GP.Controls.Add(this.relyLabel13);
            this.Leecher_GP.Controls.Add(this.relyLabel16);
            this.Leecher_GP.Controls.Add(this.Net_Check);
            this.Leecher_GP.Controls.Add(this.relyLabel22);
            this.Leecher_GP.Controls.Add(this.relyLabel15);
            this.Leecher_GP.Controls.Add(this.relyLabel2);
            this.Leecher_GP.Controls.Add(this.Site_Check);
            this.Leecher_GP.Controls.Add(this.relyLabel23);
            this.Leecher_GP.Controls.Add(this.relyLabel14);
            this.Leecher_GP.Controls.Add(this.relyLabel4);
            this.Leecher_GP.Controls.Add(this.Acc_Check);
            this.Leecher_GP.Controls.Add(this.relyLabel17);
            this.Leecher_GP.Controls.Add(this.relyLabel10);
            this.Leecher_GP.Controls.Add(this.relyLabel18);
            this.Leecher_GP.Controls.Add(this.Mobile_TXT);
            this.Leecher_GP.Controls.Add(this.Send_URL_BTN);
            this.Leecher_GP.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.Leecher_GP.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Leecher_GP.Location = new System.Drawing.Point(219, 57);
            this.Leecher_GP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Leecher_GP.Name = "Leecher_GP";
            this.Leecher_GP.ShowText = true;
            this.Leecher_GP.Size = new System.Drawing.Size(520, 382);
            this.Leecher_GP.TabIndex = 14;
            this.Leecher_GP.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // relyLabel11
            // 
            this.relyLabel11.AutoSize = true;
            this.relyLabel11.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel11.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel11.ForeColor = System.Drawing.Color.Teal;
            this.relyLabel11.Location = new System.Drawing.Point(134, 335);
            this.relyLabel11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel11.Name = "relyLabel11";
            this.relyLabel11.Size = new System.Drawing.Size(233, 25);
            this.relyLabel11.TabIndex = 16;
            this.relyLabel11.Text = "- Developed by AGC007 -";
            // 
            // relyLabel1
            // 
            this.relyLabel1.AutoSize = true;
            this.relyLabel1.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic);
            this.relyLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel1.Location = new System.Drawing.Point(31, 96);
            this.relyLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel1.Name = "relyLabel1";
            this.relyLabel1.Size = new System.Drawing.Size(98, 25);
            this.relyLabel1.TabIndex = 17;
            this.relyLabel1.Text = "- License  :";
            // 
            // LIC_Check
            // 
            this.LIC_Check.AutoSize = true;
            this.LIC_Check.BackColor = System.Drawing.Color.Transparent;
            this.LIC_Check.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.LIC_Check.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.LIC_Check.Location = new System.Drawing.Point(131, 96);
            this.LIC_Check.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LIC_Check.Name = "LIC_Check";
            this.LIC_Check.Size = new System.Drawing.Size(20, 25);
            this.LIC_Check.TabIndex = 18;
            this.LIC_Check.Text = "-";
            // 
            // relyLabel12
            // 
            this.relyLabel12.AutoSize = true;
            this.relyLabel12.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic);
            this.relyLabel12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel12.Location = new System.Drawing.Point(31, 144);
            this.relyLabel12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel12.Name = "relyLabel12";
            this.relyLabel12.Size = new System.Drawing.Size(136, 25);
            this.relyLabel12.TabIndex = 15;
            this.relyLabel12.Text = "- License Type :";
            // 
            // LIC_Type
            // 
            this.LIC_Type.AutoSize = true;
            this.LIC_Type.BackColor = System.Drawing.Color.Transparent;
            this.LIC_Type.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.LIC_Type.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.LIC_Type.Location = new System.Drawing.Point(167, 144);
            this.LIC_Type.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LIC_Type.Name = "LIC_Type";
            this.LIC_Type.Size = new System.Drawing.Size(20, 25);
            this.LIC_Type.TabIndex = 19;
            this.LIC_Type.Text = "-";
            // 
            // relyLabel9
            // 
            this.relyLabel9.AutoSize = true;
            this.relyLabel9.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel9.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))));
            this.relyLabel9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.relyLabel9.Location = new System.Drawing.Point(145, 58);
            this.relyLabel9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel9.Name = "relyLabel9";
            this.relyLabel9.Size = new System.Drawing.Size(231, 25);
            this.relyLabel9.TabIndex = 11;
            this.relyLabel9.Text = "- Sms Bomber Ver 2.0.0 -";
            // 
            // relyLabel13
            // 
            this.relyLabel13.AutoSize = true;
            this.relyLabel13.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic);
            this.relyLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel13.Location = new System.Drawing.Point(31, 193);
            this.relyLabel13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel13.Name = "relyLabel13";
            this.relyLabel13.Size = new System.Drawing.Size(196, 25);
            this.relyLabel13.TabIndex = 14;
            this.relyLabel13.Text = "- Internet Connection :";
            // 
            // relyLabel16
            // 
            this.relyLabel16.AutoSize = true;
            this.relyLabel16.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel16.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.relyLabel16.ForeColor = System.Drawing.Color.Lime;
            this.relyLabel16.Location = new System.Drawing.Point(151, 21);
            this.relyLabel16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel16.Name = "relyLabel16";
            this.relyLabel16.Size = new System.Drawing.Size(225, 25);
            this.relyLabel16.TabIndex = 10;
            this.relyLabel16.Text = "- In The Name Of God! -";
            // 
            // Net_Check
            // 
            this.Net_Check.AutoSize = true;
            this.Net_Check.BackColor = System.Drawing.Color.Transparent;
            this.Net_Check.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Net_Check.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Net_Check.Location = new System.Drawing.Point(229, 193);
            this.Net_Check.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Net_Check.Name = "Net_Check";
            this.Net_Check.Size = new System.Drawing.Size(20, 25);
            this.Net_Check.TabIndex = 20;
            this.Net_Check.Text = "-";
            // 
            // relyLabel15
            // 
            this.relyLabel15.AutoSize = true;
            this.relyLabel15.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic);
            this.relyLabel15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel15.Location = new System.Drawing.Point(31, 240);
            this.relyLabel15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel15.Name = "relyLabel15";
            this.relyLabel15.Size = new System.Drawing.Size(161, 25);
            this.relyLabel15.TabIndex = 12;
            this.relyLabel15.Text = "- Site Connection :";
            // 
            // Site_Check
            // 
            this.Site_Check.AutoSize = true;
            this.Site_Check.BackColor = System.Drawing.Color.Transparent;
            this.Site_Check.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Site_Check.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Site_Check.Location = new System.Drawing.Point(195, 240);
            this.Site_Check.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Site_Check.Name = "Site_Check";
            this.Site_Check.Size = new System.Drawing.Size(20, 25);
            this.Site_Check.TabIndex = 21;
            this.Site_Check.Text = "-";
            // 
            // relyLabel14
            // 
            this.relyLabel14.AutoSize = true;
            this.relyLabel14.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Italic);
            this.relyLabel14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel14.Location = new System.Drawing.Point(28, 288);
            this.relyLabel14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel14.Name = "relyLabel14";
            this.relyLabel14.Size = new System.Drawing.Size(197, 25);
            this.relyLabel14.TabIndex = 13;
            this.relyLabel14.Text = "- Sms Api Connection :";
            // 
            // Acc_Check
            // 
            this.Acc_Check.AutoSize = true;
            this.Acc_Check.BackColor = System.Drawing.Color.Transparent;
            this.Acc_Check.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Acc_Check.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Acc_Check.Location = new System.Drawing.Point(229, 288);
            this.Acc_Check.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Acc_Check.Name = "Acc_Check";
            this.Acc_Check.Size = new System.Drawing.Size(20, 25);
            this.Acc_Check.TabIndex = 22;
            this.Acc_Check.Text = "-";
            // 
            // relyLabel3
            // 
            this.relyLabel3.AutoSize = true;
            this.relyLabel3.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel3.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel3.ForeColor = System.Drawing.Color.Green;
            this.relyLabel3.Location = new System.Drawing.Point(386, 193);
            this.relyLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel3.Name = "relyLabel3";
            this.relyLabel3.Size = new System.Drawing.Size(48, 25);
            this.relyLabel3.TabIndex = 18;
            this.relyLabel3.Text = "Fast";
            this.relyLabel3.Visible = false;
            // 
            // relyLabel19
            // 
            this.relyLabel19.AutoSize = true;
            this.relyLabel19.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel19.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.relyLabel19.ForeColor = System.Drawing.Color.Lime;
            this.relyLabel19.Location = new System.Drawing.Point(104, 36);
            this.relyLabel19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel19.Name = "relyLabel19";
            this.relyLabel19.Size = new System.Drawing.Size(225, 25);
            this.relyLabel19.TabIndex = 10;
            this.relyLabel19.Text = "- In The Name Of God! -";
            this.relyLabel19.Visible = false;
            // 
            // relyLabel20
            // 
            this.relyLabel20.AutoSize = true;
            this.relyLabel20.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel20.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel20.Location = new System.Drawing.Point(32, 147);
            this.relyLabel20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel20.Name = "relyLabel20";
            this.relyLabel20.Size = new System.Drawing.Size(293, 25);
            this.relyLabel20.TabIndex = 15;
            this.relyLabel20.Text = "- Production Date :  2022/06/30";
            this.relyLabel20.Visible = false;
            // 
            // relyLabel21
            // 
            this.relyLabel21.AutoSize = true;
            this.relyLabel21.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel21.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel21.Location = new System.Drawing.Point(32, 193);
            this.relyLabel21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel21.Name = "relyLabel21";
            this.relyLabel21.Size = new System.Drawing.Size(334, 25);
            this.relyLabel21.TabIndex = 14;
            this.relyLabel21.Text = "- Operating Speed ON Your System : ";
            this.relyLabel21.Visible = false;
            // 
            // relyLabel10
            // 
            this.relyLabel10.AutoSize = true;
            this.relyLabel10.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.relyLabel10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel10.Location = new System.Drawing.Point(75, 56);
            this.relyLabel10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel10.Name = "relyLabel10";
            this.relyLabel10.Size = new System.Drawing.Size(343, 25);
            this.relyLabel10.TabIndex = 8;
            this.relyLabel10.Text = "-  ▼ Please Enter Mobile Number ▼  -";
            // 
            // relyLabel22
            // 
            this.relyLabel22.AutoSize = true;
            this.relyLabel22.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel22.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel22.Location = new System.Drawing.Point(32, 244);
            this.relyLabel22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel22.Name = "relyLabel22";
            this.relyLabel22.Size = new System.Drawing.Size(189, 25);
            this.relyLabel22.TabIndex = 13;
            this.relyLabel22.Text = "- Developer Github :";
            this.relyLabel22.Visible = false;
            // 
            // relyLabel23
            // 
            this.relyLabel23.AutoSize = true;
            this.relyLabel23.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel23.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel23.Location = new System.Drawing.Point(32, 287);
            this.relyLabel23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel23.Name = "relyLabel23";
            this.relyLabel23.Size = new System.Drawing.Size(104, 25);
            this.relyLabel23.TabIndex = 12;
            this.relyLabel23.Text = "- Donate : ";
            this.relyLabel23.Visible = false;
            // 
            // relyLabel4
            // 
            this.relyLabel4.AutoSize = true;
            this.relyLabel4.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel4.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.relyLabel4.Location = new System.Drawing.Point(94, 102);
            this.relyLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel4.Name = "relyLabel4";
            this.relyLabel4.Size = new System.Drawing.Size(55, 25);
            this.relyLabel4.TabIndex = 19;
            this.relyLabel4.Text = "2.0.0";
            this.relyLabel4.Visible = false;
            // 
            // relyLabel18
            // 
            this.relyLabel18.AutoSize = true;
            this.relyLabel18.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel18.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel18.Location = new System.Drawing.Point(32, 102);
            this.relyLabel18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel18.Name = "relyLabel18";
            this.relyLabel18.Size = new System.Drawing.Size(71, 25);
            this.relyLabel18.TabIndex = 17;
            this.relyLabel18.Text = "- Ver : ";
            this.relyLabel18.Visible = false;
            // 
            // Mobile_TXT
            // 
            this.Mobile_TXT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Mobile_TXT.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(52)))), ((int)(((byte)(54)))));
            this.Mobile_TXT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Mobile_TXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mobile_TXT.Location = new System.Drawing.Point(33, 98);
            this.Mobile_TXT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Mobile_TXT.MaxLength = 32767;
            this.Mobile_TXT.Multiline = false;
            this.Mobile_TXT.Name = "Mobile_TXT";
            this.Mobile_TXT.ReadOnly = false;
            this.Mobile_TXT.Size = new System.Drawing.Size(461, 32);
            this.Mobile_TXT.TabIndex = 99999;
            this.Mobile_TXT.TabStop = false;
            this.Mobile_TXT.Tag = "Url";
            this.Mobile_TXT.Text = "09";
            this.Mobile_TXT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Mobile_TXT.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Mobile_TXT.TextChanged += new System.EventHandler(this.Mobile_TXT_TextChanged);
            // 
            // Send_URL_BTN
            // 
            this.Send_URL_BTN.BackColor = System.Drawing.Color.Transparent;
            this.Send_URL_BTN.BaseColor = System.Drawing.Color.Teal;
            this.Send_URL_BTN.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Send_URL_BTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Send_URL_BTN.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Send_URL_BTN.Location = new System.Drawing.Point(33, 138);
            this.Send_URL_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Send_URL_BTN.Name = "Send_URL_BTN";
            this.Send_URL_BTN.Rounded = true;
            this.Send_URL_BTN.RoundRadius = 3;
            this.Send_URL_BTN.Size = new System.Drawing.Size(228, 33);
            this.Send_URL_BTN.TabIndex = 19;
            this.Send_URL_BTN.Text = "START";
            this.Send_URL_BTN.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Send_URL_BTN.Click += new System.EventHandler(this.Send_URL_BTN_Click);
            // 
            // relyLabel17
            // 
            this.relyLabel17.AutoSize = true;
            this.relyLabel17.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel17.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))));
            this.relyLabel17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.relyLabel17.Location = new System.Drawing.Point(99, 68);
            this.relyLabel17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel17.Name = "relyLabel17";
            this.relyLabel17.Size = new System.Drawing.Size(231, 25);
            this.relyLabel17.TabIndex = 11;
            this.relyLabel17.Text = "- Sms Bomber Ver 2.0.0 -";
            this.relyLabel17.Visible = false;
            // 
            // relyLabel2
            // 
            this.relyLabel2.AutoSize = true;
            this.relyLabel2.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.relyLabel2.ForeColor = System.Drawing.Color.Lime;
            this.relyLabel2.Location = new System.Drawing.Point(179, 21);
            this.relyLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel2.Name = "relyLabel2";
            this.relyLabel2.Size = new System.Drawing.Size(150, 25);
            this.relyLabel2.TabIndex = 18;
            this.relyLabel2.Text = "- Sms Bomber -";
            // 
            // Donate_BTC_BTN
            // 
            this.Donate_BTC_BTN.BackColor = System.Drawing.Color.Transparent;
            this.Donate_BTC_BTN.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.Donate_BTC_BTN.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Donate_BTC_BTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Donate_BTC_BTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Donate_BTC_BTN.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Donate_BTC_BTN.Location = new System.Drawing.Point(136, 287);
            this.Donate_BTC_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Donate_BTC_BTN.Name = "Donate_BTC_BTN";
            this.Donate_BTC_BTN.Rounded = true;
            this.Donate_BTC_BTN.RoundRadius = 3;
            this.Donate_BTC_BTN.Size = new System.Drawing.Size(56, 25);
            this.Donate_BTC_BTN.TabIndex = 100000;
            this.Donate_BTC_BTN.Text = "BTC ";
            this.Donate_BTC_BTN.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Donate_BTC_BTN.Click += new System.EventHandler(this.Donate_BTC_BTN_Click);
            // 
            // Donate_IRR_BTN
            // 
            this.Donate_IRR_BTN.BackColor = System.Drawing.Color.Transparent;
            this.Donate_IRR_BTN.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.Donate_IRR_BTN.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Donate_IRR_BTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Donate_IRR_BTN.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Donate_IRR_BTN.Location = new System.Drawing.Point(202, 287);
            this.Donate_IRR_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Donate_IRR_BTN.Name = "Donate_IRR_BTN";
            this.Donate_IRR_BTN.Rounded = true;
            this.Donate_IRR_BTN.RoundRadius = 3;
            this.Donate_IRR_BTN.Size = new System.Drawing.Size(56, 25);
            this.Donate_IRR_BTN.TabIndex = 100001;
            this.Donate_IRR_BTN.Text = "IRR";
            this.Donate_IRR_BTN.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.Donate_IRR_BTN.Click += new System.EventHandler(this.Donate_IRR_BTN_Click);
            // 
            // GitHub_BTN
            // 
            this.GitHub_BTN.BackColor = System.Drawing.Color.Transparent;
            this.GitHub_BTN.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.GitHub_BTN.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.GitHub_BTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GitHub_BTN.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.GitHub_BTN.Location = new System.Drawing.Point(236, 244);
            this.GitHub_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.GitHub_BTN.Name = "GitHub_BTN";
            this.GitHub_BTN.Rounded = true;
            this.GitHub_BTN.RoundRadius = 3;
            this.GitHub_BTN.Size = new System.Drawing.Size(79, 25);
            this.GitHub_BTN.TabIndex = 100003;
            this.GitHub_BTN.Text = "GitHub";
            this.GitHub_BTN.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.GitHub_BTN.Visible = false;
            this.GitHub_BTN.Click += new System.EventHandler(this.GitHub_BTN_Click);
            // 
            // GP_BOX
            // 
            this.GP_BOX.BackColor = System.Drawing.Color.Transparent;
            this.GP_BOX.BaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(47)))), ((int)(((byte)(47)))));
            this.GP_BOX.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.GP_BOX.Controls.Add(this.Error_SEND_SMS_LBL);
            this.GP_BOX.Controls.Add(this.SEND_SMS_LBL);
            this.GP_BOX.Controls.Add(this.Mobile_LBL);
            this.GP_BOX.Controls.Add(this.relyLabel8);
            this.GP_BOX.Controls.Add(this.relyLabel7);
            this.GP_BOX.Controls.Add(this.relyLabel6);
            this.GP_BOX.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.GP_BOX.Location = new System.Drawing.Point(33, 178);
            this.GP_BOX.Name = "GP_BOX";
            this.GP_BOX.ShowText = true;
            this.GP_BOX.Size = new System.Drawing.Size(461, 154);
            this.GP_BOX.TabIndex = 100006;
            this.GP_BOX.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            // 
            // Error_SEND_SMS_LBL
            // 
            this.Error_SEND_SMS_LBL.AutoSize = true;
            this.Error_SEND_SMS_LBL.BackColor = System.Drawing.Color.Transparent;
            this.Error_SEND_SMS_LBL.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Error_SEND_SMS_LBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Error_SEND_SMS_LBL.Location = new System.Drawing.Point(369, 108);
            this.Error_SEND_SMS_LBL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Error_SEND_SMS_LBL.Name = "Error_SEND_SMS_LBL";
            this.Error_SEND_SMS_LBL.Size = new System.Drawing.Size(23, 25);
            this.Error_SEND_SMS_LBL.TabIndex = 25;
            this.Error_SEND_SMS_LBL.Text = "0";
            // 
            // SEND_SMS_LBL
            // 
            this.SEND_SMS_LBL.AutoSize = true;
            this.SEND_SMS_LBL.BackColor = System.Drawing.Color.Transparent;
            this.SEND_SMS_LBL.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.SEND_SMS_LBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.SEND_SMS_LBL.Location = new System.Drawing.Point(255, 68);
            this.SEND_SMS_LBL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SEND_SMS_LBL.Name = "SEND_SMS_LBL";
            this.SEND_SMS_LBL.Size = new System.Drawing.Size(23, 25);
            this.SEND_SMS_LBL.TabIndex = 23;
            this.SEND_SMS_LBL.Text = "0";
            // 
            // Mobile_LBL
            // 
            this.Mobile_LBL.AutoSize = true;
            this.Mobile_LBL.BackColor = System.Drawing.Color.Transparent;
            this.Mobile_LBL.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Mobile_LBL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Mobile_LBL.Location = new System.Drawing.Point(129, 24);
            this.Mobile_LBL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Mobile_LBL.Name = "Mobile_LBL";
            this.Mobile_LBL.Size = new System.Drawing.Size(34, 25);
            this.Mobile_LBL.TabIndex = 20;
            this.Mobile_LBL.Text = "09";
            // 
            // relyLabel8
            // 
            this.relyLabel8.AutoSize = true;
            this.relyLabel8.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel8.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.relyLabel8.Location = new System.Drawing.Point(25, 24);
            this.relyLabel8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel8.Name = "relyLabel8";
            this.relyLabel8.Size = new System.Drawing.Size(96, 25);
            this.relyLabel8.TabIndex = 19;
            this.relyLabel8.Text = "- Mobile :";
            // 
            // relyLabel7
            // 
            this.relyLabel7.AutoSize = true;
            this.relyLabel7.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel7.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.relyLabel7.Location = new System.Drawing.Point(25, 108);
            this.relyLabel7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel7.Name = "relyLabel7";
            this.relyLabel7.Size = new System.Drawing.Size(325, 25);
            this.relyLabel7.TabIndex = 18;
            this.relyLabel7.Text = "- Number of errors in sending SMS :";
            // 
            // relyLabel6
            // 
            this.relyLabel6.AutoSize = true;
            this.relyLabel6.BackColor = System.Drawing.Color.Transparent;
            this.relyLabel6.Font = new System.Drawing.Font("Segoe UI", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.relyLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.relyLabel6.Location = new System.Drawing.Point(25, 68);
            this.relyLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.relyLabel6.Name = "relyLabel6";
            this.relyLabel6.Size = new System.Drawing.Size(213, 25);
            this.relyLabel6.TabIndex = 16;
            this.relyLabel6.Text = "- Number of SMS sent :";
            // 
            // TimeSMS
            // 
            this.TimeSMS.Interval = 10000;
            this.TimeSMS.Tick += new System.EventHandler(this.TimeSMS_Tick);
            // 
            // STOP_URL_BTN
            // 
            this.STOP_URL_BTN.BackColor = System.Drawing.Color.Transparent;
            this.STOP_URL_BTN.BaseColor = System.Drawing.Color.Teal;
            this.STOP_URL_BTN.ClickColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.STOP_URL_BTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.STOP_URL_BTN.HoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.STOP_URL_BTN.Location = new System.Drawing.Point(269, 138);
            this.STOP_URL_BTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.STOP_URL_BTN.Name = "STOP_URL_BTN";
            this.STOP_URL_BTN.Rounded = true;
            this.STOP_URL_BTN.RoundRadius = 3;
            this.STOP_URL_BTN.Size = new System.Drawing.Size(225, 33);
            this.STOP_URL_BTN.TabIndex = 100007;
            this.STOP_URL_BTN.Text = "STOP";
            this.STOP_URL_BTN.TextColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(243)))), ((int)(((byte)(243)))));
            this.STOP_URL_BTN.Click += new System.EventHandler(this.STOP_URL_BTN_Click);
            // 
            // Form1
            // 
            this.AccentColor = System.Drawing.Color.Black;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 447);
            this.Controls.Add(this.Exit_BTN);
            this.Controls.Add(this.About_BTN);
            this.Controls.Add(this.Leech_BTN);
            this.Controls.Add(this.Home_BTN);
            this.Controls.Add(this.Leecher_GP);
            this.Controls.Add(this.xuiClock1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "SMS Bomber [v2] By AGC007™";
            this.TitleText = "SMS Bomber [v2] By AGC007™";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Controls.SetChildIndex(this.xuiClock1, 0);
            this.Controls.SetChildIndex(this.Leecher_GP, 0);
            this.Controls.SetChildIndex(this.Home_BTN, 0);
            this.Controls.SetChildIndex(this.Leech_BTN, 0);
            this.Controls.SetChildIndex(this.About_BTN, 0);
            this.Controls.SetChildIndex(this.Exit_BTN, 0);
            this.Leecher_GP.ResumeLayout(false);
            this.Leecher_GP.PerformLayout();
            this.GP_BOX.ResumeLayout(false);
            this.GP_BOX.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private RelyUI.Controls.RelyButton Exit_BTN;
        private RelyUI.Controls.RelyButton About_BTN;
        private RelyUI.Controls.RelyButton Leech_BTN;
        private RelyUI.Controls.RelyButton Home_BTN;
        private XanderUI.XUIClock xuiClock1;
        private RelyUI.Controls.RelyGroupBox Leecher_GP;
        private RelyUI.Controls.RelyLabel relyLabel3;
        private RelyUI.Controls.RelyLabel relyLabel11;
        private RelyUI.Controls.RelyLabel relyLabel9;
        private RelyUI.Controls.RelyLabel relyLabel16;
        private RelyUI.Controls.RelyLabel relyLabel19;
        private RelyUI.Controls.RelyLabel relyLabel20;
        private RelyUI.Controls.RelyLabel relyLabel21;
        private RelyUI.Controls.RelyLabel relyLabel10;
        private RelyUI.Controls.RelyLabel relyLabel22;
        private RelyUI.Controls.RelyLabel relyLabel12;
        private RelyUI.Controls.RelyLabel relyLabel23;
        private RelyUI.Controls.RelyLabel relyLabel13;
        private RelyUI.Controls.RelyLabel relyLabel4;
        private RelyUI.Controls.RelyLabel relyLabel14;
        private RelyUI.Controls.RelyLabel relyLabel15;
        private RelyUI.Controls.RelyLabel relyLabel1;
        private RelyUI.Controls.RelyLabel LIC_Check;
        private RelyUI.Controls.RelyLabel LIC_Type;
        private RelyUI.Controls.RelyLabel Net_Check;
        private RelyUI.Controls.RelyLabel Site_Check;
        private RelyUI.Controls.RelyLabel Acc_Check;
        private RelyUI.Controls.RelyLabel relyLabel18;
        private RelyUI.Controls.RelyTextBox Mobile_TXT;
        private RelyUI.Controls.RelyButton Send_URL_BTN;
        private RelyUI.Controls.RelyLabel relyLabel17;
        private RelyUI.Controls.RelyLabel relyLabel2;
        private RelyUI.Controls.RelyButton Donate_BTC_BTN;
        private RelyUI.Controls.RelyButton Donate_IRR_BTN;
        private RelyUI.Controls.RelyButton GitHub_BTN;
        private RelyUI.Controls.RelyGroupBox GP_BOX;
        private RelyUI.Controls.RelyLabel relyLabel6;
        private RelyUI.Controls.RelyLabel relyLabel7;
        private RelyUI.Controls.RelyLabel relyLabel8;
        private RelyUI.Controls.RelyLabel Mobile_LBL;
        private RelyUI.Controls.RelyLabel Error_SEND_SMS_LBL;
        private RelyUI.Controls.RelyLabel SEND_SMS_LBL;
        public System.Windows.Forms.Timer TimeSMS;
        private RelyUI.Controls.RelyButton STOP_URL_BTN;
    }
}

